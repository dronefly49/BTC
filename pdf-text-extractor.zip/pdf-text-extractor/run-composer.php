<?php
// Set the COMPOSER_HOME environment variable
putenv('COMPOSER_HOME=' . __DIR__ . '/composer_home');

// Run Composer to install smalot/pdfparser
exec('php composer.phar require smalot/pdfparser 2>&1', $output, $return_var);

// Display all output
echo implode("\n", $output);
echo "\nDone with exit code: " . $return_var;
?>