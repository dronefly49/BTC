<?php
/*
 Plugin Name: PDF Text Extractor
 Description: Extract text from uploaded PDFs.
 Version: 1.0
*/

require __DIR__ . '/vendor/autoload.php'; // Load Composer dependencies

use Smalot\PdfParser\Parser;

// Function to extract text from a PDF
function extract_pdf_text($pdf_file_path) {
    $parser = new Parser();
    $pdf = $parser->parseFile($pdf_file_path);
    return $pdf->getText();
}

// Shortcode for extracting text from a PDF URL
add_shortcode('extract_pdf', function($atts) {
    $pdf_url = $atts['url'];
    $file_path = ABSPATH . str_replace(site_url('/'), '', $pdf_url);
    if (file_exists($file_path)) {
        $text = extract_pdf_text($file_path);
        return nl2br($text);
    } else {
        return "PDF file not found.";
    }
});